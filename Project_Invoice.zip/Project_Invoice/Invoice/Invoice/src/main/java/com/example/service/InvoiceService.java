package com.example.service;

import java.util.LinkedHashMap;
import java.util.List;

public interface InvoiceService {
    void save(LinkedHashMap<String, List<String>> m1);
}
