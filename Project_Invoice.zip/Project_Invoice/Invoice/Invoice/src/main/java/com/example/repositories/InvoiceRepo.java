package com.example.repositories;

import com.example.entity.Invoice_Info;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface InvoiceRepo extends CrudRepository<Invoice_Info,Long> {
    @Query(value = "select app_id from invoice_info where Xref = ?1 and total_loan_amt = ?2",nativeQuery = true)
    Long dedupe(Long xref,Double total_loan_amt);
}
