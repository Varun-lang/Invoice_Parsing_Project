package com.example.controller;

import com.example.repositories.InvoiceRepo;
import com.example.service.InvoiceService;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
public class MainController {

    InvoiceService invoiceService;
    InvoiceRepo invoiceRepo;

    static String fileName="";

    @Autowired
    public MainController(InvoiceService invoiceService,InvoiceRepo invoiceRepo) {
        this.invoiceService  = invoiceService;
        this.invoiceRepo = invoiceRepo;
    }

    static LinkedHashMap<String, List<String>> ml = new LinkedHashMap<>();

    @RequestMapping("/")
    public String first(){
        return "first";
    }

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "Failure";
        }

        try {
            String uploadDir = "C:\\Users\\varun\\Desktop\\Project_Invoice\\Invoice\\Invoice\\src\\main\\uploads";
            String filePath = uploadDir +"\\"+ file.getOriginalFilename();
            fileName = file.getOriginalFilename();
            File dest = new File(filePath);
            file.transferTo(dest);
            return "redirect:/extractPdf";
        } catch (IOException e) {
            return "redirect:/?error=Failed to upload the file. Please try again.";
        }
    }

    @RequestMapping("/extractPdf")
    public String extractPdf() {
        try {
            File file = new File("C:\\Users\\varun\\Desktop\\Project_Invoice\\Invoice\\Invoice\\src\\main\\uploads\\"+fileName);
            PDDocument document = PDDocument.load(file);
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(document);

            ml.put("App ID", new ArrayList<>());
            ml.put("Xref", new ArrayList<>());
            ml.put("Settlement Date", new ArrayList<>());
            ml.put("Broker", new ArrayList<>());
            ml.put("Sub Broker", new ArrayList<>());
            ml.put("Borrower Name", new ArrayList<>());
            ml.put("Description", new ArrayList<>());
            ml.put("Total Loan Amount", new ArrayList<>());
            ml.put("Comm Rate", new ArrayList<>());
            ml.put("Upfront", new ArrayList<>());
            ml.put("Upfront Incl GST", new ArrayList<>());

            List<String> lst = new ArrayList<>();
            String[] lines = text.split("\\r\\n");
            for(int i=0;i<lines.length;i++){
                if(lines[i].matches("^\\d.*")){
                    lst.add(lines[i]);
                }
            }
            extractNumbers(lst);
            extractString(lst);
            document.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        invoiceService.save(ml);//save invoice
        return "Success";
    }

    public void extractNumbers(List<String> lst) {
        for (String str : lst) {
            String[] substrings = str.split("\\s+");
            int k = -1;
            List<String> kg = new ArrayList<>();
            for (String substr : substrings) {
                k += 1;
                if (Character.isDigit(substr.charAt(0))) {
                    if (k == 0) {
                        kg.add(0,substr);
                        ml.get("App ID").add(kg.get(0));
                    } else if (k == 1) {
                        kg.add(substr);
                        ml.get("Xref").add(kg.get(1));
                    } else if (k == 2) {
                        kg.add(substr);
                        ml.get("Settlement Date").add(kg.get(2));
                    } else if (k == substrings.length - 4) {
                        kg.add(substr);
                        ml.get("Total Loan Amount").add(kg.get(3));
                    } else if (k == substrings.length - 3) {
                        kg.add(substr);
                        ml.get("Comm Rate").add(kg.get(4));
                    } else if (k == substrings.length - 2) {
                        kg.add(substr);
                        ml.get("Upfront").add(kg.get(5));
                    } else if (k == substrings.length - 1) {
                        kg.add(substr);
                        ml.get("Upfront Incl GST").add(kg.get(6));
                    }
                }
            }
        }
    }

    public void extractString(List<String> lst) {
        for(int i = 0; i < lst.size(); i++) {
            String sub = lst.get(i);
            int j=0;
            while (!(Character.isUpperCase(sub.charAt(j)))) {
                j++;
            }
            int k=j;
            while(!((Character.isDigit(sub.charAt(k)))&&(Character.isWhitespace(sub.charAt(k-1))))){
                k++;
            }
            String ans = sub.substring(j,k-1);
            getString(ans);
        }
    }

    public void getString(String str) {
        String [] starr = str.split(" ");
        int s = 0;
        int u = 0;
        int flag = 0;
        String subBr = "";
        String broker = "";
        String subBroker ="" ;
        String borrower;
        String finalBrwr = "";
        StringBuilder value = new StringBuilder();
        String upFront = "";
        for (int i = 0;i<starr. length;i++) {
            if (starr[i].equals("")) {
                starr[i] = "%%";
            } else if (starr[i].length() == 1) {
                starr[i] += '$';
            } else if (starr[i].contains("-") && Character.isLowerCase(starr[i].charAt(i - 1))) {
                int k = 0;
                while (!(Character.isLowerCase(starr[i].charAt(k)) && Character.isUpperCase(starr[i].charAt(k + 1)))) {
                    k++;
                }
                String[] add = {starr[i].substring(k + 1)};
                starr[i] = starr[i].substring(0, k + 1);
                subBr = add[0];
                flag = 1;
            }
        }
        for (int i = 0; i<starr.length; i++) {
            String s1 = starr[i];
            if ((Character.isLowerCase(s1.charAt(1))) || (s1.length() == 3 && s1.toUpperCase().equals(s1))) {
                value.append(s1).append(" ");
            } else if (s1.equals("%%")) {
                s = 1;
                broker = value + " ";
                value = new StringBuilder();
            } else if (Character.isUpperCase(s1.charAt(1)) && u == 0) {
                u = 1;
                subBroker = value.toString();
                value = new StringBuilder();
                if (flag == 1) {
                    value.append(subBr).append(" ");
                }
                value.append(s1).append(" ");
            } else if (u == 1) {
                if (s1.contains("$")) {
                    value.append(s1.charAt(0)).append(" ");
                } else {
                    value.append(s1).append(" ");
                }
            } else {
                value = new StringBuilder(s1);
            }
        }
        borrower = value.toString();
        if(s==0){
            broker = subBroker;
            subBroker = " ";
        }
        for(int i=0;i<borrower.length();i++) {
            if (Character.isLowerCase(borrower.charAt(i))) {
                finalBrwr = borrower.substring(0, i - 2);
                break;
            }
        }
        List<String> ans = new ArrayList<String>();

        ans.add(broker.trim());
        ans.add(subBroker.trim());
        ans.add(finalBrwr.trim());
        ans.add("Upfront Commission");

        ml.get("Broker").add(ans.get(0));
        ml.get("Sub Broker").add(ans.get(1));
        ml.get("Borrower Name").add(ans.get(2));
        ml.get("Description").add(ans.get(3));
    }
}
