package com.example.service;

import com.example.entity.Invoice_Info;
import com.example.repositories.InvoiceRepo;
import com.sun.xml.bind.v2.runtime.output.SAXOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class InvoiceServiceImpl implements InvoiceService{

    InvoiceRepo invoiceRepo;

    @Autowired
    public InvoiceServiceImpl(InvoiceRepo invoiceRepo) {
        this.invoiceRepo = invoiceRepo;
    }


    @Override
    public void save(LinkedHashMap<String, List<String>> m1) {

        Set<Pair<String,Double>> s1= new HashSet<>();
        int z = m1.get("Xref").size();
        Invoice_Info invoice_Info = new Invoice_Info();
        for (int i = 0; i < z; i++) {
            for (Map.Entry<String, List<String>> entry : m1.entrySet()) {
                Long check = invoiceRepo.dedupe(Long.parseLong(m1.get("Xref").get(i)), Double.parseDouble(m1.get("Total Loan Amount").get(i).replaceAll(",","")));
                if(check != null){
                    break;
                }
                List<String> values = entry.getValue();
                if ( i < values.size() && !s1.contains(Pair.of(m1.get("Xref").get(i), Double.parseDouble(m1.get("Total Loan Amount").get(i).replaceAll(",",""))))) {
                    invoice_Info.setApp_id(Long.parseLong(m1.get("App ID").get(i)));
                    invoice_Info.setXref(Long.parseLong(m1.get("Xref").get(i)));
                    invoice_Info.setSettlement_date(m1.get("Settlement Date").get(i));
                    invoice_Info.setBroker(m1.get("Broker").get(i));
                    invoice_Info.setSub_broker(m1.get("Sub Broker").get(i));
                    invoice_Info.setBorrower_name(m1.get("Borrower Name").get(i));
                    invoice_Info.setDescription(m1.get("Description").get(i));
                    invoice_Info.setTotal_loan_amt(Double.parseDouble(m1.get("Total Loan Amount").get(i).replaceAll(",","")));
                    invoice_Info.setComm_rate(Double.parseDouble(m1.get("Comm Rate").get(i).replaceAll(",","")));
                    invoice_Info.setUpfront(Double.parseDouble(m1.get("Upfront").get(i).replaceAll(",","")));
                    invoice_Info.setUpfront_gst(Double.parseDouble(m1.get("Upfront Incl GST").get(i).replaceAll(",","")));
                    invoiceRepo.save(invoice_Info);
                    s1.add(Pair.of(m1.get("Xref").get(i), Double.parseDouble(m1.get("Total Loan Amount").get(i).replaceAll(",",""))));
                }
                else{
                    break;
                }
                break;
            }
        }
    }
}

