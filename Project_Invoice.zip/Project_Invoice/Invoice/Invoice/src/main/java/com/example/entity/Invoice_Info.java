package com.example.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Entity
public class Invoice_Info {
    @Id
    Long app_id;
    Long xref;
    String settlement_date;
    String broker;
    String sub_broker;
    String borrower_name;
    String description;
    @Column(precision = 5, scale = 2)
    double total_loan_amt;
    double comm_rate;
    double upfront;
    double upfront_gst;
}
